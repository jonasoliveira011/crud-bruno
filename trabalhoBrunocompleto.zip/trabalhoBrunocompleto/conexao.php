<?php
 $conexao = mysqli_connect('localhost','root','')
 or die('could not connect:'.mysqli_error(die));

 mysqli_select_db($conexao, 'vigilancia_db')
or die('could not connect:'.mysqli_error(die));

?>