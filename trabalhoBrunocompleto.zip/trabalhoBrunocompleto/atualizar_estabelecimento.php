<?php   
    include 'conexao.php';

    $id_estabelecimentos = $_GET["id"];
    $action_estabelecimentos = "execute-update_estabelecimento";

    $select = 'SELECT estabelecimentos,identificacao,irregularidade FROM estabelecimento WHERE estabelecimento_id= '.$_GET["id"];
    $resultado = mysqli_query($conexao,$select) or die ("query failed:".mysqli_error());

    $coluna = mysqli_fetch_row($resultado);
    mysqli_close($conexao);

    print_r($coluna);

    $estabelecimento = $coluna[0];
    $identificacao = $coluna[1];
    $irregularidades = $coluna[2];

?>