<?php   

$razao_soc = isset($_POST["razao_social"]) ? $_POST["razao_social"] : null;

$nome_fant = isset($_POST["nome_fantasia"]) ? $_POST["nome_fantasia"] : null;

$inscricao_mun = isset($_POST["inscricao_municipal"]) ? $_POST["inscricao_municipal"] : null;

$inscricao_est = isset($_POST["inscricao_estadual"]) ? $_POST["inscricao_estadual"] : null;

$phone = isset($_POST["phone"]) ? $_POST["phone"] : null;

$email = isset($_POST["email"]) ? $_POST["email"] : null;

if($razao_soc!= "" and $nome_fant!= "" and $inscricao_mun!= "" and $inscricao_est!= "" and $phone!= "" and $email!= ""){
    include 'conexao.php';

    $query = 'INSERT INTO dadosestabelecimento(razao_soc, nome_fant, inscricao_mun, inscricao_est, phone, email)
     VALUES ("'.$razao_soc.'","'.$nome_fant.'","'.$inscricao_mun.'","'.$inscricao_est.'","'.$phone.'","'.$email.'")';
    $result = mysqli_query($conexao,$query) or die('query failed:'.mysqli_error(die));
    mysqli_close($conexao);

    echo "Cadastrado com Sucesso!!!";
}
?>

<a href="index.php">Voltar</a>
