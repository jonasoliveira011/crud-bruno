    <?php

    $lei = "";
    $classif_lei = "";
    $conclusao = "";

    $razao_soc = "";
    $nome_fant = "";
    $inscricao_mun = "";
    $inscricao_est = "";
    $phone = "";
    $email = "";

    $estabelecimento = "";
    $identificacao = "";
    $irregularidades = "";

    $nome = "";
    $cpf_prof = "";
    $data = "";
    $fone = "";
    $email_prof = "";

    $risco = "";
    $data_min = "";
    $data_max = "";
    $codigo = "";
    $descricao = "";

    $id_auto_termo = "";
    $id_dados_estabelecimentos = "";
    $id_estabelecimentos = "";
    $id_prof = "";
    $id_nivel_estab = "";
    $id = "";

    $action = "cadastro_termo.php";
    $action_dados_estab = "cadastro_dados_estab.php";
    $action_estabelecimentos = "cadastro_estabelecimentos.php";
    $action_profissionais = "cadastro_prof.php";
    $action_nivel = "cadastro_nivel_risco.php";


    if (isset($_GET["action"]) and $_GET["action"] == "update") {
        include 'atualizar_termo.php';
        $action = "execultar_atualizacao_termo.php";
    }
    if (isset($_GET["action"]) and $_GET["action"] == "update_dados_estab") {
        include 'atualizar_dados_estab.php';
        $action_dados_estab = "execultar_dados_estab.php";
    }
    if (isset($_GET["action"]) and $_GET["action"] == "update_estabelecimento") {
        include 'atualizar_estabelecimento.php';
        $action_estabelecimentos = "execultar_estabelecimento.php";
    }
    if (isset($_GET["action"]) and $_GET["action"] == "update_profissionais") {
        include 'atualizar_prof.php';
        $action_profissionais = "execultar_prof.php";
    }

    if (isset($_GET["action"]) and $_GET["action"] == "update_nivel") {
        include 'atualizar_nivel.php';
        $action_nivel = "execultar_nivel.php";
    }

    ?>
    <!DOCTYPE html>
    <html lang="pt-br">

    <head>
        <meta charset="UTF-8">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Asap:ital,wght@1,700&family=Nunito:wght@700&family=Yellowtail&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="./css/style.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

        <title></title>
    </head>

    <body>

        <nav class=menu id="menu">
            <ul>
                <li><a href="#" class="menu-z" for="vigi">HOME</a></li>
                <li><a href="#" class="menu-z" for="auto-termo">auto termo</a></li>
                <li><a href="#" class="menu-z" for="dados-estabelecimentos">Dados Estabelecimentos</a></li>
                <li><a href="#" class="menu-z" for="estabelecimentos">Estabelecimentos</a></li>
                <li><a href="#" class="menu-z" for="dados-profissionais">Dados Profissionais</a></li>
                <li><a href="#" class="menu-z" for="nivel-estabelecimentos">Nivel Estabelecimentos</a></li>
            </ul>
        </nav>

        <div class="content-auto-termo" id="auto-termo">
            <fieldset>
                <legend>AUTO TERMO</legend>
                <form action="<?php echo $action ?>" method="post">

                    <label for="lei_id">LEI/ BASE:</label>
                    <input type="text" id="lei_id" name="lei_base" value="<?php echo $lei ?>"><br><br>
                    <select id="name">
                        <option value="name">AUTO DE</option>
                        <option value="name">PELO FATO DE</option>
                        <option value="name">TERMO DE</option>

                        <label for="classificacao_id"></label>
                        <input type="text" id="classificacao_id" name="classificacao_lei" value="<?php echo $classif_lei ?>"><br><br>
                    </select>
                    <label for="conclusao_pena">CONCLUSÃO/ PENA:</label>
                    <input type="name" id="conclusao_pena" name="conclusao_pena" value="<?php echo $conclusao ?>"><br>

                    <?php
                    if ($id_auto_termo != "") { ?>
                        <input type="hidden" value="<?php echo $id_auto_termo; ?>" name="id">
                    <?php } ?>
                    <input type="submit">
                </form>
            </fieldset>
            <div>
                <?php
                include 'lista_termo.php';
                ?>
            </div>
        </div>

        <div class="content-dados-estabelecimentos" id="dados-estabelecimentos">
            <fieldset>
                <legend>DADOS ESTABELECIMENTOS:</legend>
                <form action="<?php echo $action_dados_estab ?>" method="post">
                    <label for="razao_id">RAZÃO SOCIAL:</label>
                    <input type="text" id="razao_id" name="razao_social" value=" <?php echo $razao_soc ?>"><br><br>
                    <label for="nomefant_id">NOME FANTASIA:</label>
                    <input type="text" id="nomefant_id" name="nome_fantasia" value=" <?php echo $nome_fant ?>"><br><br>
                    <label for="inscr_mun_id">INSCRIÇÃO MUNICIPAL:</label>
                    <input type="text" id="inscr_mun_id" name="inscricao_municipal" value="<?php echo $inscricao_mun ?>"><br><br>
                    <label for="inscr_est_id">INSCRIÇÃO ESTADUAL:</label>
                    <input type="text" id="inscr_est_id" name="inscricao_estadual" value="<?php echo $inscricao_est ?>"><br><br>
                    <label for="phone_id">TELEFONE:</label>
                    <input type="tel" id="phone_id" name="phone" value="<?php echo $phone ?>"><br><br>
                    <label for="email_id">E-MAIL:</label>
                    <input type="email" id="email_id" name="email" value="<?php echo $email ?>"><br><br>

                    <?php
                    if ($id_dados_estabelecimentos != "") { ?>
                        <input type="hidden" value="<?php echo $id_dados_estabelecimentos; ?>" name="id">
                    <?php } ?>
                    <input type="submit">
                </form>
            </fieldset>
            <div>
                <?php
                include 'lista_dados_estab.php';
                ?>
            </div>
        </div>

        <div class="content-estabelecimentos" id="estabelecimentos">
            <form action="<?php echo $action_estabelecimentos ?>" method="post">
                <fieldset>
                    <legend>ESTABELECIMENTOS:</legend>
                    <label for="estabelecimento"></label><br><br>
                    <input type="text" id="estabelecimento" name="estabelecimento" value="<?php echo $estabelecimento ?>">
                </fieldset>
                <fieldset>
                    <legend>IDENTIFICAÇÃO DE SETORES:</legend>
                    <label for="ident_setor"></label>
                    <input type="text" id="identificacao_setores" name="ident_setor" value="<?php echo $identificacao ?>"><br><br>
                </fieldset>
                <fieldset>
                    <legend>IRREGULARIDADES ENCOTRADAS:</legend>
                    <label for="irregularidades"></label>
                    <input type="text" id="irregularidades_encotradas" name="irregularidades" value="<?php echo $irregularidades ?>"><br><br>
                </fieldset>
                <?php
                if ($id_estabelecimentos != "") { ?>
                    <input type="hidden" value="<?php echo $id_estabelecimentos; ?>" name="id">
                <?php } ?>
                <input type="submit">
            </form>
            <div>
                <?php
                include 'lista_estabelecimento.php';
                ?>
            </div>
        </div>

        <div class="content-dados-profissionais" id="dados-profissionais">
            <fieldset>
                <legend>DADOS DOS PROFISSIONAIS:</legend>
                <form action="<?php echo $action_profissionais ?>" method="post">
                    <label for="nome">NOME:</label>
                    <input type="text" id="nome" name="nome" value="<?php echo $nome ?>"><br><br>
                    <label for="cpf_prof">CPF:</label>
                    <input type="text" name="cpf_prof" value="<?php echo $cpf_prof ?>" \ placeholder="xxx.xxx.xxx-xx" pattern="\d{3}\.\d{3}\.\d{3}-\d{2}\" \ title="Digite um cpf no formato: xxx.xxx.xxx-xx"> <BR><BR>
                    <label for="date">DATA DE NASCIMENTO:</label>
                    <input type="date" id="date" name="date" value="<?php echo $data ?>"><br><br>
                    <label for="fone">TELEFONE:</label>
                    <input type="tel" id="phone" name="fone" value="<?php echo $fone ?>"><br><br>
                    <label for="email_prof">E-MAIL:</label>
                    <input type="email" id="email_profissional" name="email_prof" value="<?php echo $email_prof ?>"><br><br>
                    <?php
                    if ($id_prof != "") { ?>
                        <input type="hidden" value="<?php echo $id_prof; ?>" name="id">
                    <?php } ?>
                    <input type="submit">
                </form>
            </fieldset>
            <div>
                <?php
                include 'lista_profissionais.php';
                ?>
            </div>
        </div>
        <div class="content-nivel-estabelecimentos" id="nivel-estabelecimentos">
            <form action="<?php echo $action_nivel ?>" method="post">
                <fieldset>
                    <legend>NÍVEL DE RÍSCO DO ESTABELECIMENTO:</legend>
                    <input type="radio" id="risco_baixo" name="risco_clas" value="Risco Baixo">
                    <label for="risco_clas">I - Risco Baixo - Não sujeito à concessão de Alvará Sanitário</label><br>
                    <input type="radio" id="risco_medio" name="risco_clas" value="Risco Médio">
                    <label for="risco_clas">II - Risco Médio - Necessita de Alvará Sanitário, sem Inspeção prévia</label><br>
                    <input type="radio" id="risco_alto" name="risco_clas" value="Risco Alto">
                    <label for="risco_clas">III - Risco Alto - Necessita de Alvará Sanitário, com Inspeção prévia</label><br><br>
                </fieldset>

                <fieldset>
                    <legend>CRONOGRAMA DE INSPEÇÃO:</legend>
                    <label for="datemin">Data última inspeção realizada:</label>
                    <input type="date" id="datemin" name="datemin" min="2021-12-31" value="<?php echo $data_min ?>"><br>
                    <label for="datemax">Data próxima inspeção a ser realizada:</label>
                    <input type="date" id="datemax" name="datemax" max="2022-12-31" value="<?php echo $data_max ?>"><br><br>
                </fieldset>
                <fieldset>
                    <legend>ATIVIDADES ECONÔMICAS:</legend>
                    <label for="codigo">CÓDIGO:</label>
                    <input type="text" name="codigo" value="<?php echo $codigo ?>" \ placeholder="xx.xx-x-xx" pattern="\d{2}\.\d{2}\-\d{1}-\d{2}\" \ title="Digite um cpf no formato: xx.xx-x-xx"><br>
                    <label for="descricao">DESCRIÇÃO DA ATIVIDADE ECONÔMICA PRINCIPAL:</label>
                    <input type="text" id="name" name="descricao" value="<?php echo $descricao ?>"><BR><BR>
                </fieldset>
                <?php
                if ($id_nivel_estab != "") { ?>
                    <input type="hidden" value="<?php echo $id_nivel_estab; ?>" name="id">
                <?php } ?>
                <input type="submit">
            </form>
            <div>
                <?php
                include 'lista_nivel.php';
                ?>
            </div>
        </div>
        <div id="contato">
            <h2>Contato</h2>
            <p>Para mais informações entrar em contato</p>
            <div>

                <p><a href="tel:32998267677">(32) 998267677</a></p>
            </div>
            <div>

                <p><a href="vigilancia@pedroteixeira.mg.gov.br">vigilancia@pedroteixeira.mg.gov.br</a></p>
            </div>
        </div>

        <footer>
            <a href="#menu">VOLTAR</a>
            <p>Desenvolvido por Jonas de Oliveira Silva</p>
        </footer>
        <script>
            $(document).ready(function() {
                $(".content-auto-termo").hide();
                $(".content-dados-estabelecimentos").hide();
                $(".content-estabelecimentos").hide();
                $(".content-dados-profissionais").hide();
                $(".content-nivel-estabelecimentos").hide();

                $("a.menu-z").click(function() {
                    $(".content-topo").hide();
                    $(".content-auto-termo").hide();
                    $(".content-dados-estabelecimentos").hide();
                    $(".content-estabelecimentos").hide();
                    $(".content-dados-profissionais").hide();
                    $(".content-nivel-estabelecimentos").hide();

                    $("#" + $(this).attr("for")).show();
                });

            })
        </script>
    </body>

    </html>