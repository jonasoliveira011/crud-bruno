<html>

<head>

</head>

<body>
    <table>
        <thead>
            <th>Lei</th>
            <th>Classif_lei</th>
            <th>Conclusao</th>
            <th>Ações</th>
        </thead>
        <tbody>
            <?php
            include 'conexao.php';

            $selecionar = 'SELECT * FROM auto_termo';
            $resultado = mysqli_query($conexao, $selecionar) or die('query failed:' . mysqli_error(die));

            while ($linha = mysqli_fetch_array($resultado, MYSQLI_ASSOC)) {
            ?>
                <tr>
                    <td><?= $linha["lei"] ?></td>
                    <td><?= $linha["classif_lei"] ?></td>
                    <td><?= $linha["conclusao"] ?></td>

                    <td><a href='deletar_termo.php?id=<?php echo $linha["id"]?>&action=delete'>DELETAR</a></td>
                    <td><a href='index.php?id=<?php echo $linha["id"]?>&action=update'>UPDATE</a></td>
                </tr>
            <?php
            }
            mysqli_close($conexao);
            ?>
        </tbody>

    </table>
</body>

</html>