<html>

<head>

</head>

<body>
    <table>
        <thead>
            <th>Razao_soc</th>
            <th>Nome_fant</th>
            <th>Inscricao_mun</th>
            <th>Inscricao_est</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Ações</th>
        </thead>
        <tbody>
            <?php
            include 'conexao.php';

            $selecionar = 'SELECT * FROM dadosestabelecimento';
            $resultado = mysqli_query($conexao, $selecionar) or die('query failed:' . mysqli_error(die));

            while ($linha = mysqli_fetch_array($resultado, MYSQLI_ASSOC)) {
            ?>
                <tr>
                    <td><?= $linha["razao_soc"] ?></td>
                    <td><?= $linha["nome_fant"] ?></td>
                    <td><?= $linha["inscricao_mun"] ?></td>
                    <td><?= $linha["inscricao_est"] ?></td>
                    <td><?= $linha["phone"] ?></td>
                    <td><?= $linha["email"] ?></td>
                    

                    <td><a href='deletar_dados_estab.php?id=<?php echo $linha["dadosest_id"]?>&action=delete'>DELETAR</a></td>
                    <td><a href='index.php?id=<?php echo $linha["dadosest_id"]?>&action=update_dados_estab'>UPDATE</a></td>
                </tr>
            <?php
            }
            mysqli_close($conexao);
            ?>
        </tbody>

    </table>
</body>

</html>