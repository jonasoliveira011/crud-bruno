<?php   

$lei = isset($_POST["lei_base"]) ? $_POST["lei_base"] : null;

$classif_lei = isset($_POST["classificacao_lei"]) ? $_POST["classificacao_lei"] : null;

$conclusao = isset($_POST["conclusao_pena"]) ? $_POST["conclusao_pena"] : null;

if($lei!= "" and $classif_lei!= "" and $conclusao!= ""){
    include 'conexao.php';

    $query = 'INSERT INTO auto_termo(lei, classif_lei, conclusao) VALUES ("'.$lei.'","'.$classif_lei.'","'.$conclusao.'")';
    $result = mysqli_query($conexao,$query) or die('query failed:'.mysqli_error(die));
    mysqli_close($conexao);

    echo "Cadastrado com Sucesso!!!";
}
?>

<a href="index.php">Voltar</a>