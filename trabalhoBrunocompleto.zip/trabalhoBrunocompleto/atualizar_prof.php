<?php   
    include 'conexao.php';

    $id_prof = $_GET["id"];
    $action_profissionais = "execute-update_profissionais";

    $select = 'SELECT nome,cpf_prof,data_nasc,fone,email_prof FROM profissionais WHERE prof_id= '.$_GET["id"];
    print_r($select);
    $resultado = mysqli_query($conexao,$select) or die ("query failed:".mysqli_error());

    $coluna = mysqli_fetch_row($resultado);
    mysqli_close($conexao);

    print_r($coluna);

    $nome = $coluna[0];
    $cpf_prof = $coluna[1];
    $data = $coluna[2];
    $fone = $coluna[3];
    $email_prof = $coluna[4];

?>