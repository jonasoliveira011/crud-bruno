<?php   

$nome = isset($_POST["nome"]) ? $_POST["nome"] : null;

$cpf_prof = isset($_POST["cpf_prof"]) ? $_POST["cpf_prof"] : null;

$data = isset($_POST["date"]) ? $_POST["date"] : null;

$fone = isset($_POST["fone"]) ? $_POST["fone"] : null;

$email_prof = isset($_POST["email_prof"]) ? $_POST["email_prof"] : null;

if($nome!= "" and $cpf_prof!= "" and $data!= "" and $fone!= "" and $email_prof!= "" ){
    include 'conexao.php';

    $query = 'INSERT INTO profissionais(nome,cpf_prof,data_nasc,fone,email_prof)
     VALUES ("'.$nome.'","'.$cpf_prof.'","'.$data.'","'.$fone.'","'.$email_prof.'")';
    $result = mysqli_query($conexao,$query) or die('query failed:'.mysqli_error(die));
    mysqli_close($conexao);

    echo "Cadastrado com Sucesso!!!";
}
?>

<a href="index.php">Voltar</a>